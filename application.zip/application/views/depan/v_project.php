<main id="main">

<!-- ======= About Section ======= -->
<section id="about" class="about">
<div class="container">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos sed eaque possimus porro. Quisquam culpa, pariatur voluptates ratione quod suscipit nam, magnam, iusto deserunt veritatis esse reprehenderit praesentium. Cumque, quidem.</p>
</div>
</section>
</main>