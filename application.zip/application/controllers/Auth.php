<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function index()
	{
		$this->load->view('v_login');
	}

	public function cek_login()
	{
		$email = $this->input->post('pengguna_email');
		$password = $this->input->post('pengguna_password', TRUE);
		$hashPass = password_hash($password, PASSWORD_DEFAULT);
		$test = password_verify($password, $hashPass);

		//Query cek user
		$this->db->where('pengguna_email', $email);
		$users = $this->db->get('tbl_pengguna');
		
		if($users->num_rows() > 0) {
			$users = $users->row_array();
			if (password_verify($password, $user['pengguna_password'])){
				$this->session->set_userdate($user);
				redirect('Dashboard', 'refresh');
			}else{
				redirect('Auth', 'refresh');
			}
			}else{
				$this->session->set_flashdata('status_login', 'email atau password yang anda masukan salah');
				redirect('Auth', 'refresh');
			}
		}
	}

