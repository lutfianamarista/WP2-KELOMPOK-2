<?php
class Mylibrary {

    function libsaya(){
        return 'Selamat datang ilham di kendari coding';
    }
}